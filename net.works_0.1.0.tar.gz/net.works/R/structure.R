#' @title Firt step in directed network description
#' @description Build the structure of the directed network and create a network visualization using the igraph package.
#' @param file - The file containing your network data
#' @param from - The starting point for each of the edges in the network
#' @param to - The ending point for each of the edges in the network
#' @export
#' @examples
#' structure(flights, flights$"From", flights$"To")

structure <- function(file, from, to){
  edges <- data.frame(source = from, destination = to)
  all_nodes <- as.vector(as.matrix(edges[,c("source", "destination")]))
  nodes <- unique(all_nodes)
  library(igraph)
  net <<- igraph::graph_from_data_frame(d=edges, vertices=nodes, directed=TRUE)
  par(mar=rep(0,4))
  igraph::plot.igraph(net,
              edge.arrow.size=0,
              edge.color="gray",
              edge.curved=TRUE,
              edge.width=2,
              vertex.size=3,
              vertex.color=NA,
              vertex.frame.color=NA,
              layout=layout.fruchterman.reingold
  )
}
