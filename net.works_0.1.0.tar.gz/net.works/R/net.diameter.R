#' @title Network Diameter Assessment
#' @description Analyzes the structure of a given network and provides the network diameter and specific diameter path
#' @param network.structure - The network being used in the degree calculations
#' @export
#' @examples
#' diameter(net)


net.diameter <- function(network.structure){
  net_diameter <<- igraph::diameter(network.structure, directed=T, weights=NA)
  print(net_diameter)
  #print(net_diameter)
}
