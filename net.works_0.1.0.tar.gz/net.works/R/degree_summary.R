#' @title Summary of Network Degree
#' @description Create a list of node degrees; plot the distribution of node degree with the network
#' @param network - The network being used in the degree calculations
#' @export
#' @examples
#' degree_summary(net)



degree_summary <- function(network){
  library(igraph)
  degree_list <<- igraph::degree(network, mode = "in", loops = TRUE, normalized = FALSE)
  degree_dist <<- igraph::degree.distribution(network, cumulative = TRUE)
  #print(degree_list)
  par()
  hist(degree_list,
       breaks=50,
       main=" Network Degree Distribution",
       border=TRUE,
       axes=TRUE)
}

