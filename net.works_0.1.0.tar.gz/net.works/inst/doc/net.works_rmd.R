## ------------------------------------------------------------------------

library(net.works)

dim(flights)


## ------------------------------------------------------------------------

#How many unique flights are there?
AA_count <- length(which(flights$airline == "AA"))
AA_count


## ------------------------------------------------------------------------

#Create a new dataset from 'flights' that only includes American Airlines flights. Sort by airline code "AA".
AA <- flights[which(flights$airline == "AA"), ]
View(AA)


## ------------------------------------------------------------------------
# Use the structure function to generate the network graph.
# AA is the file contianing flight path data.
# AA$source.airport is the column in the AA file with the source airport ("from")
# AA$destination.airport is the column in the AA file with the destination airport ("to")
structure(AA, AA$source.airport, AA$destination.airport)

## ------------------------------------------------------------------------
degree_summary(net)

## ------------------------------------------------------------------------
net.diameter(net)

